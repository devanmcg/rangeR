


We can look at each of these responses individually:

![plot of chunk unnamed-chunk-2](survey analysis2/unnamed-chunk-2-1.png)

Or we can combine the factors and show two categorical variables at once:

![plot of chunk unnamed-chunk-3](survey analysis2/unnamed-chunk-3-1.png)

Classic bar debate:

![plot of chunk unnamed-chunk-4](survey analysis2/unnamed-chunk-4-1.png)

```
## Error: ggplot2 doesn't know how to deal with data of class list
```

Where you all are from. The bigger the symbol, the more of you are from there:

![plot of chunk unnamed-chunk-5](survey analysis2/unnamed-chunk-5-1.png)

```
## Error in select_impl(.data, vars): found duplicated column name: NA, NA, NA
```

On your relationship with data: 

![plot of chunk unnamed-chunk-6](survey analysis2/unnamed-chunk-6-1.png)

