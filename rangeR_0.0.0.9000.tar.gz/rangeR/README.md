# rangeR

## Background 

This is mainly a repository of material for my graduate-level class *Analysis of Ecosystems*, which I teach at North Dakota State University. 