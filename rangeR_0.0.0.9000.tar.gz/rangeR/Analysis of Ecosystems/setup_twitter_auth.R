setup_twitter_oauth(consumer_key="DkCWM47PcESDalqMmLL9mv4tv",
                    consumer_secret="A2fdVWPoMLipQQAmysh05tSWY7bjEZHMG6jih9Ud4yqspyqUYf", 
                    access_token ="89751769-JV3m7b3ZFJvhVGrJLZ3njoYU8yZWQinRLXxviBF46", 
                    access_secret="LpOsq0hjEkux5pyi7fgdTjlFUNqP83yXwrFd7S5FegpSp")